// const express = require('express');
// const router = express.Router();
// const Location = require('../models/Location');
// const axios = require('axios');
// const dotenv = require('dotenv');

// dotenv.config();

// const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY;

// router.get('/locations', async (req, res) => {
//   try {
//     const locations = await Location.find();
//     res.json(locations);
//   } catch (err) {
//     res.status(500).send(err);
//   }
// });

// router.post('/distance', async (req, res) => {
//   const { currentLocation, fixedLocations } = req.body;

//   try {
//     const promises = fixedLocations.map(async (location) => {
//       const response = await axios.get(
//         `https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&origins=${currentLocation.lat},${currentLocation.lng}&destinations=${location.lat},${location.lng}&key=${GOOGLE_MAPS_API_KEY}`
//       );
//       return response.data.rows[0].elements[0].distance.value / 1000;
//     });

//     const distances = await Promise.all(promises);
//     res.json(distances);
//   } catch (err) {
//     res.status(500).send(err);
//   }
// });

// module.exports = router;
